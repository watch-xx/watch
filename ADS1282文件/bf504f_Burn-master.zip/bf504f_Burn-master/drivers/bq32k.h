#ifndef _BQ32K_H
#define _BQ32K_H


#include <time.h>
#include "globdefs.h"

void   set_rtc_sec_ticks(long);
long   get_rtc_sec_ticks(void);

#endif /*bq32k.h  */
