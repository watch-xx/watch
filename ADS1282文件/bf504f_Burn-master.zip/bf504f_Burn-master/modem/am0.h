#ifndef _AM0_H
#define _AM0_H

#include "globdefs.h"

int am0_prg_modem(void *);
void am0_close(void);

#endif /* am3.h */
