#ifndef		_SINTAB_H
#define 	_SINTAB_H

#include "globdefs.h"

#define 	SIN_TABLE_SIZE			4000

u16             get_sin_table(u32);

#endif /* sintab.h */

