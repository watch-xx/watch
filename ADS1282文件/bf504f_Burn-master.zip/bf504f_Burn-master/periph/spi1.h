#ifndef _SPI1_H
#define _SPI1_H

#include "globdefs.h"

void SPI1_init(void);
void SPI1_close(void);
u16  SPI1_write_read(u16);

#endif /* spi1.h  */
